# Security Policy

Report vulnerabilities by opening an issue or contacting the repository owner.
